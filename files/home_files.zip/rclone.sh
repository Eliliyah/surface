#!/usr/bin/bash
rclone --vfs-cache-mode writes mount proton: ~/proton
